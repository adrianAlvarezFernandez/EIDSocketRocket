//
//  EIDSocketRocket.h
//  EIDSocketRocket
//
//  Created by Adrián Álvarez Fernández on 22/05/2017.
//  Copyright © 2017 Electronic ID. All rights reserved.
//

#import <EIDSocketRocket/SRWebSocket.h>

//! Project version number for EIDSocketRocket.
FOUNDATION_EXPORT double EIDSocketRocketVersionNumber;

//! Project version string for EIDSocketRocket.
FOUNDATION_EXPORT const unsigned char EIDSocketRocketVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EIDSocketRocket/PublicHeader.h>


